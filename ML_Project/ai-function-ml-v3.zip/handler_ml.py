﻿import json
import joblib
import os

model_path = '/function/storage/model.pkl'
if os.path.exists(model_path):
    model = joblib.load(model_path)
else:
    model = None

def handler(event, context):
    try:
        if isinstance(event, dict) and 'body' in event:
            body = json.loads(event['body'])
        else:
            body = event
        
        data = body.get('data', {})
        
        completed = data.get('CompletedLessons', 0)
        missed = data.get('MissedLessons', 0)
        total = data.get('TotalRequiredLessons', 28)
        
        if model is None:
            progress = completed / total if total > 0 else 0
            score = progress * 100
            if score >= 80:
                recommendation = "✅ Студент ГОТОВ к экзамену"
                level = "Высокая"
                can_exam = True
            elif score >= 60:
                recommendation = "📊 Студент может сдавать экзамен"
                level = "Средняя"
                can_exam = True
            else:
                recommendation = "⚠️ Студент НЕ ГОТОВ к экзамену"
                level = "Низкая"
                can_exam = False
        else:
            features = [[completed, missed, total]]
            proba = model.predict_proba(features)[0][1]
            prediction = model.predict(features)[0]
            score = round(proba * 100, 1)
            
            if prediction == 1:
                recommendation = "✅ Студент ГОТОВ к экзамену"
                level = "Высокая"
                can_exam = True
            else:
                recommendation = "⚠️ Студент НЕ ГОТОВ к экзамену"
                level = "Низкая"
                can_exam = False
        
        suggestions = []
        if completed >= total:
            suggestions.append(f"✅ Все {total} уроков пройдены")
        else:
            suggestions.append(f"📚 Пройдено {completed} из {total} уроков")
        if missed > 0:
            suggestions.append(f"⚠️ {missed} прогулов")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'score': score,
                'level': level,
                'recommendation': recommendation,
                'can_exam': can_exam,
                'suggestions': suggestions
            }, ensure_ascii=False),
            'headers': {'Content-Type': 'application/json; charset=utf-8'}
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)}),
            'headers': {'Content-Type': 'application/json'}
        }
